/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author swaha_000
 */
@Entity
@Table(name="round")
public class Round implements Serializable {
    
    @Id
    private String id;
    
    @Column
    private String scheme;

    @Column
    private float total_time_taken;
    
    @Column
    private boolean final_State;
    @Column
    private boolean State1;
    @Column
    private boolean State2;
    @Column
    private boolean State3;
    @Column
    private boolean State4;
    @Column
    private boolean State5;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getScheme() {
        return scheme;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

    public float getTotal_time_taken() {
        return total_time_taken;
    }

    public void setTotal_time_taken(float total_time_taken) {
        this.total_time_taken = total_time_taken;
    }

    public boolean getFinal_State() {
        return final_State;
    }

    public void setFinal_State(boolean final_State) {
        this.final_State = final_State;
    }

    public boolean isState1() {
        return State1;
    }

    public void setState1(boolean State1) {
        this.State1 = State1;
    }

    public boolean isState2() {
        return State2;
    }

    public void setState2(boolean State2) {
        this.State2 = State2;
    }

    public boolean isState3() {
        return State3;
    }

    public void setState3(boolean State3) {
        this.State3 = State3;
    }

    public boolean isState4() {
        return State4;
    }

    public void setState4(boolean State4) {
        this.State4 = State4;
    }

    public boolean isState5() {
        return State5;
    }

    public void setState5(boolean State5) {
        this.State5 = State5;
    }

    public boolean isState6() {
        return State6;
    }

    public void setState6(boolean State6) {
        this.State6 = State6;
    }

    public boolean isState7() {
        return State7;
    }

    public void setState7(boolean State7) {
        this.State7 = State7;
    }

    public float getFirst_Challenge_time() {
        return first_Challenge_time;
    }

    public void setFirst_Challenge_time(float first_Challenge_time) {
        this.first_Challenge_time = first_Challenge_time;
    }

    public float getSecond_Challenge_time() {
        return second_Challenge_time;
    }

    public void setSecond_Challenge_time(float second_Challenge_time) {
        this.second_Challenge_time = second_Challenge_time;
    }

    public float getThird_Challenge_time() {
        return third_Challenge_time;
    }

    public void setThird_Challenge_time(float third_Challenge_time) {
        this.third_Challenge_time = third_Challenge_time;
    }

    public float getFourth_Challenge_time() {
        return fourth_Challenge_time;
    }

    public void setFourth_Challenge_time(float fourth_Challenge_time) {
        this.fourth_Challenge_time = fourth_Challenge_time;
    }

    public float getFifth_Challenge_time() {
        return fifth_Challenge_time;
    }

    public void setFifth_Challenge_time(float fifth_Challenge_time) {
        this.fifth_Challenge_time = fifth_Challenge_time;
    }

    public float getSixth_Challenge_time() {
        return sixth_Challenge_time;
    }

    public void setSixth_Challenge_time(float sixth_Challenge_time) {
        this.sixth_Challenge_time = sixth_Challenge_time;
    }

    public float getSeventh_Challenge_time() {
        return seventh_Challenge_time;
    }

    public void setSeventh_Challenge_time(float seventh_Challenge_time) {
        this.seventh_Challenge_time = seventh_Challenge_time;
    }
    @Column
    private boolean State6;
    @Column
    private boolean State7;
    
       
    @Column
    private float first_Challenge_time;
    
    @Column
    private float second_Challenge_time;
    @Column
    private float third_Challenge_time;
    @Column
    private float fourth_Challenge_time;
    @Column
    private float fifth_Challenge_time;
    @Column
    private float sixth_Challenge_time;
    @Column
    private float seventh_Challenge_time;
    
}