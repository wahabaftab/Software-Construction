

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.*;
import static java.lang.System.out;

/**
 * @author Wahab
 */
public class Authentication {

    private static RoundDAO roundDAO = new RoundDAO();

    private static void populateDB() {
        try {
            // Open the input file
            FileInputStream fstream = new FileInputStream("src/test_two-anon.csv");
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));

            // Read file line by line
            String strLine;
            while ((strLine = br.readLine()) != null) {
                // Create a new city
                Round r = new Round();
                r.setId("123adasdasd");
                r.setState1(true);
                r.setState2(true);
                r.setState3(false);
                r.setState4(true);                
                r.setState5(true);
                r.setState6(false);
                r.setState7(true);
                r.setTotal_time_taken((float) 123.23);
                r.setFinal_State(true);
                r.setScheme("CO-CHC");
                r.setFirst_Challenge_time((float) 0.2);
                r.setSecond_Challenge_time(2);
                r.setThird_Challenge_time((float) 12.2);
                r.setFourth_Challenge_time((float) 4.23);
                r.setFifth_Challenge_time((float) 22.1);
                r.setSixth_Challenge_time((float) 23.1);
                r.setSeventh_Challenge_time((float) 2.12);
                

                

                // TODO: Parse line to set City object
                System.out.println(strLine);

                // Persist object
                roundDAO.save(r);
            }

            // Close the input stream
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // if (this-is-the-first-run) {
            // TODO: Populate database only if this is the first execution of program
            populateDB();
        // }

        // else {
            // TODO: Add other lab tasks here
        // }

    }

}
