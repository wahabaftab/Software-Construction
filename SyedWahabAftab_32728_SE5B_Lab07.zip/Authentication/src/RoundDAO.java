



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 */
public class RoundDAO {

    public void save(Round round) {
        // Get session factory and open a new session
        SessionFactory factory = HibernateUtil.getSessionFactory();
        Session session = factory.openSession();

        // Begin transaction
        Transaction t = session.beginTransaction();

        // Persist city and commit changes
        session.persist(round);
        t.commit();

        // Close the session
        session.close();
    }

}
